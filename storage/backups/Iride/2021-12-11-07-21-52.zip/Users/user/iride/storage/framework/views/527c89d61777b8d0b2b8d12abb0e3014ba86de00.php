<?php if($entry->canAddCrudTrait): ?>
    <a href="<?php echo e(url($crud->route.'/'.$entry->getKey().'/add-crud-trait')); ?>" class="btn btn-sm btn-outline-primary"><i class="la la-th-list"></i> Add CrudTrait</a>
<?php endif; ?>
<?php /**PATH /Users/user/iride/vendor/backpack/devtools/src/../resources/views/buttons/add_crud_trait.blade.php ENDPATH**/ ?>