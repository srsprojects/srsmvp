<?php if($column['show_modifiers']): ?>
    <div class="form-group col-md-1 mb-1 px-1 text-center">
    <label class="mb-1"><?php echo e(ucfirst($label)); ?></label>
<?php endif; ?>
	<input
        type="<?php echo e($type); ?>"
		wire:model="columns.<?php echo e($column_index); ?>.modifiers.<?php echo e($label); ?>"
		name="columns[<?php echo e($column_index); ?>][modifiers][<?php echo e($label); ?>]"
        class="form-control "
		wire:change="selectModifier(<?php echo e($column_index); ?>, '<?php echo e($label); ?>')"
		<?php if(in_array($label, $invalid_modifiers)): ?>
			readonly
		<?php else: ?>
		<?php if(isset($modifier_config['auto_modifiers']) && in_array($label, $modifier_config['auto_modifiers'])): ?>
		checked="checked"
		disabled
		<?php endif; ?>
		<?php endif; ?>

        />
<?php if($column['show_modifiers']): ?>
</div>
<?php endif; ?>
<?php /**PATH /Users/user/iride/vendor/backpack/devtools/src/../resources/views/livewire/migration-schema/modifiers/checkbox.blade.php ENDPATH**/ ?>