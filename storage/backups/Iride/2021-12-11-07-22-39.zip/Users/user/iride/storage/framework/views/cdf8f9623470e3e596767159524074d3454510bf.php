<?php if(\Alert::getMessages()): ?>
	<script>
	$( document ).ready(function() {
		var $showPublishModalAlerts = window.livewire.find('<?php echo e($_instance->id); ?>').get('showPublishModalAlerts');
		if ($showPublishModalAlerts) {
			var $alertsFlashedFromLivewire = JSON.parse('<?php echo json_encode(\Alert::getMessages(), 15, 512) ?>');
			
			for (var type in $alertsFlashedFromLivewire) {
				let messages = new Set($alertsFlashedFromLivewire[type]);
				messages.forEach(text => new Noty({type, text}).show());
			}
		}
	});
	</script>
<?php endif; ?><?php /**PATH /Users/user/iride/vendor/backpack/devtools/src/../resources/views/livewire/partials/alerts.blade.php ENDPATH**/ ?>