<?php echo e($slot); ?>

<?php /**PATH /Users/user/iride/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>